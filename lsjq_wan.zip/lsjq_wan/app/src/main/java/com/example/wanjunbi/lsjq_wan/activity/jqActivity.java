package com.example.wanjunbi.lsjq_wan.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


import com.amap.api.maps.AMap;
import com.amap.api.maps.CameraUpdate;
import com.amap.api.maps.CameraUpdateFactory;
import com.amap.api.maps.MapView;
import com.amap.api.maps.model.LatLng;
import com.amap.api.maps.model.LatLngBounds;
import com.amap.api.maps.model.MarkerOptions;
import com.amap.api.maps.model.PolygonOptions;
import com.amap.api.maps.model.PolylineOptions;
import com.example.wanjunbi.lsjq_wan.R;
import com.example.wanjunbi.lsjq_wan.db.DBHandle;
import com.example.wanjunbi.lsjq_wan.entity.Location;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Created by wanjunbi on 2017/1/25.
 */

public class jqActivity extends Activity{
    private MapView mapView;
    private AMap aMap;
    private CameraUpdate cameraUpdate;
    List<Location> spots = new ArrayList<Location>();
    List<Location> bounds = new ArrayList<Location>();

    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.jianghanlu);
        Button buildings = (Button)findViewById(R.id.buildings);
        Button pics = (Button)findViewById(R.id.pics);
        TextView jqTitle = (TextView)findViewById(R.id.jiequTitle);
        TextView jqIntroduction =(TextView)findViewById(R.id.jqIntroduction);

        final Intent intent = getIntent();
        final int jiequID = (int) intent.getIntExtra("jiequID",0);

        switch (jiequID) {
            case 1:
                jqTitle.setText("江汉路及中山大道片区");
                break;
            case 2:
                jqTitle.setText("青岛路片区");
                break;
            case 3:
                jqTitle.setText("八七会址片区");
                break;
            case 4:
                jqTitle.setText("一元路片区");
                break;
            case 5:
                jqTitle.setText("昙华林片区");
                break;
        }

        String info = new DBHandle().GetJqIntroduction(jiequID);
        jqIntroduction.setText(info);

        buildings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentb = new Intent(jqActivity.this,buildinglistActivity.class);
                intentb.putExtra("jiequID",jiequID);
                startActivity(intentb);
            }
        });
        pics.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentp = new Intent(jqActivity.this,picsActivity.class);
                intentp.putExtra("jiequID",jiequID);
                startActivity(intentp);
            }
        });

        spots = new DBHandle().GetJQMap(jiequID);
        bounds = new DBHandle().GetMaps(jiequID);
        //地图模块显示街区区域及建筑项地址
        mapView = (MapView) findViewById(R.id.jqMap);
        mapView.onCreate(savedInstanceState);
        init();



    }

    public void init(){
        if (aMap == null){
            aMap = mapView.getMap();
            addMarkerToMap();
            addBoundsToMap();
        }
    }

    public void addMarkerToMap(){
        //Iterator iterator = spots.iterator();
        //while (iterator.hasNext())
        double lat,lng;
        String name;
        Location spot;
        for (int i=0;i<spots.size();i++) {
            spot = spots.get(i);
            lat = spot.getLat().doubleValue();
            lng = spot.getLng().doubleValue();
            name = spot.getName();
            MarkerOptions markerOptions = new MarkerOptions().position(new LatLng(lat,lng)).draggable(false).title(name);
            aMap.addMarker(markerOptions);
        }


    }

    public void addBoundsToMap(){
        List<LatLng> Area = new ArrayList<LatLng>();
        double lat,lng;
        Location boundPoint;
        double maxLat=bounds.get(0).getLat().doubleValue();
        double maxLng=bounds.get(0).getLng().doubleValue();
        double minLat=maxLat;
        double minLng=maxLng;
        for (int i=0;i<bounds.size();i++){
            boundPoint = bounds.get(i);
            lat = boundPoint.getLat().doubleValue();
            lng = boundPoint.getLng().doubleValue();
            Area.add(new LatLng(lat,lng));

            //对比得到街区矩形范围
            //maxLat = lat >= maxLat? lat:maxLat;
            if (lat > maxLat){maxLat = lat;}
            if (lng > maxLng){maxLng = lng;}
            if (lat < minLat){minLat = lat;}
            if (lng < minLng){minLng = lng;}
        }
        Area.add(Area.get(0));
        System.out.println("boundsArea:"+maxLat+" "+maxLng+"   "+minLat+" "+minLng);
        PolylineOptions polylineOptions = new PolylineOptions().addAll(Area).color(0xFF6495ed).width(8);
        aMap.addPolyline(polylineOptions);
        LatLngBounds latLngBounds = new LatLngBounds(new LatLng(minLat,minLng),new LatLng(maxLat,maxLng));
        cameraUpdate = CameraUpdateFactory.newLatLngBoundsRect(latLngBounds,1,1,1,1);
        aMap.moveCamera(cameraUpdate);
    }

    @Override
    protected void onResume() {
        super.onResume();
        mapView.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        mapView.onPause();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        mapView.onSaveInstanceState(outState);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mapView.onDestroy();
    }
}
