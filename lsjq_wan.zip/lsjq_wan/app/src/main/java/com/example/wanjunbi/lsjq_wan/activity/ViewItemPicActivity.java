package com.example.wanjunbi.lsjq_wan.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.wanjunbi.lsjq_wan.R;
import com.example.wanjunbi.lsjq_wan.Stroage.BitmapStorage;
import com.example.wanjunbi.lsjq_wan.Stroage.DiskLruCache;
import com.example.wanjunbi.lsjq_wan.ViewPagerAdapter;
import com.example.wanjunbi.lsjq_wan.db.DBHandle;
import com.example.wanjunbi.lsjq_wan.db.SQLConfig;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * Created by wanjunbi on 2017/4/1.
 */

public class ViewItemPicActivity extends Activity implements ViewPager.OnPageChangeListener{
    private ViewPager pager;
    private PagerAdapter pagerAdapter = null;
    private TextView number;
    private List<String> itemPicsPath = new ArrayList<String>();
    private List<String> itemPicsUrl = new ArrayList<String>();
    private int ID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pics);
        pager = (ViewPager) findViewById(R.id.viewpager);

        Intent intent = this.getIntent();
        Bundle bundle = intent.getExtras();
        ID = bundle.getInt("ID");
        System.out.println("buildingID:"+ID);

        //开启线程获取图片地址信息，得到后设置PagerAdapter及Listener
        MyThread myThread = new MyThread();
        Thread thread = new Thread(myThread);
        thread.start();

        //读取DiskLruCache中以buildingID为key的bitmap
        /*
        BitmapStorage storage = new BitmapStorage(ID);
        Bitmap itemPic = storage.getBitmap();
        picView.setImageBitmap(itemPic);
        */
        //picView.setImageBitmap(pic);

        //使用viewPager查看whjz对应项图片
    }

    @Override
    public void onPageScrollStateChanged(int state) {

    }

    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

    }

    @Override
    public void onPageSelected(int position) {
        if(position == itemPicsPath.size()-1){
            Toast.makeText(ViewItemPicActivity.this,"最后一张图片",Toast.LENGTH_SHORT).show();
        }else if(position == 0){
            Toast.makeText(ViewItemPicActivity.this,"第一张图片",Toast.LENGTH_SHORT).show();
        }
        number = (TextView)findViewById(R.id.number);
        number.setText(position+1 +"/"+ itemPicsPath.size());
        pagerAdapter.notifyDataSetChanged();
    }


    class MyThread implements Runnable{
        @Override
        public void run() {
            Looper.prepare();
            boolean urlDownload = picUrlDownload();
            if(urlDownload){
                Message msg = new Message();
                msg.what = 10;
                mHandlerUI.sendMessage(msg);
            }else {
                Message msg = new Message();
                msg.what = -1;
                mHandlerUI.sendMessage(msg);
            }
        }
    }

    @SuppressLint("NewApi")
    private boolean picUrlDownload(){
        try{
            itemPicsPath = new DBHandle().GetItemPics(ID);
        }catch (Exception e){
            e.printStackTrace();
        }

        if(itemPicsPath.isEmpty()){
            return false;
        }else{
            for(int i=0;i<itemPicsPath.size();i++){
                itemPicsUrl.add("Http://" + SQLConfig.IP + "/" + itemPicsPath.get(i));
            }
        }
        pagerAdapter = new ViewPagerAdapter(this, itemPicsUrl);
        pager.setOnPageChangeListener(this);
        return true;
    }

    private Handler mHandlerUI = new Handler(){
        public void handleMessage(Message msg){
            switch (msg.what){
                case 10:
                    //下载完picsUrlList，设置PagerAdapter
                    pager.setAdapter(pagerAdapter);
                    break;
                default:
                    //下载失败
                    break;
            }
        }
    };
}


