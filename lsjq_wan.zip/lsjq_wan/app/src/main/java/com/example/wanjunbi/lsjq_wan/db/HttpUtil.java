package com.example.wanjunbi.lsjq_wan.db;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import org.apache.http.conn.ConnectTimeoutException;
import org.codehaus.jackson.map.ObjectMapper;

import java.io.BufferedReader;
import java.io.DataInput;
import java.io.DataInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.FutureTask;

/**
 * Created by wanjunbi on 2017/3/3.
 * 换成HttpClient ？？
 */

public class HttpUtil {

    /**
     * 用于只用传入一个参数时
     * @param path   servlet地址
     * @param param  参数名
     * @param value  参数值
     * @return
     * @throws Exception
     */
    public String GetRequest(final String path,final String param,final String value) throws Exception{
        FutureTask<String> task = new FutureTask<String>(new Callable<String>() {
            @Override
            public String call() throws Exception {
                StringBuffer result = new StringBuffer();
                try{
                    String searchPath = path+"?"+param+"="+value;
                    URL url = new URL(searchPath);
                    HttpURLConnection con = null;
                    con = (HttpURLConnection)url.openConnection();
                    con.setConnectTimeout(5000);
                    //con.setRequestMethod("GET");
                    con.setDoOutput(false);
                    con.setDoInput(true);
                    con.setRequestProperty("Accept","image/gif, image/jpeg, image/pjpeg, image/pjpeg");
                    con.setRequestProperty("Accept-Language","zh-CN");
                    con.setRequestProperty("Charset","UTF-8");

                    BufferedReader bufferedReader = null;
                    String str = null;
                    bufferedReader = new BufferedReader(new InputStreamReader(con.getInputStream()));
                    while ((str = bufferedReader.readLine()) != null) {
                        result.append(str);
                    }

                    if(con != null){
                        con.disconnect();
                        con = null;
                    }
                    return result.toString();
                }catch (ConnectTimeoutException eTimeOut){
                    System.out.println("eTimeOut,连接超时");
                }catch (SocketTimeoutException eSocketTimeOut){
                    System.out.println("eSocketTimeOut,响应超时");
                }catch (FileNotFoundException eFileNotFound){
                    System.out.println("eFileNotFound,由FileInputStream,FileOutputStream抛出:  "+eFileNotFound.getMessage());
                }catch (IOException eIO){
                    eIO.printStackTrace();
                }catch (Exception e){
                    e.printStackTrace();
                }
                return null;
            }
        });
        new Thread(task).start();
        return task.get();
    }

    /**
     *
     * @param path
     * @param params
     * @return
     * @throws Exception
     */
    public String PostRequest(final String path, final Map<String,String> params) throws Exception{
        FutureTask<String> task = new FutureTask<String>(
                new Callable<String>() {
                    @Override
                    public String call() {
                        StringBuffer result = new StringBuffer();

                        try{
                            URL url = new URL(path);
                            HttpURLConnection conn = null;
                            conn = (HttpURLConnection)url.openConnection();
                            conn.setConnectTimeout(5000);
                            //conn.setRequestMethod("POST");
                            //
                            conn.setDoOutput(true);
                            conn.setDoInput(true);
                            conn.setRequestProperty("Accept","image/gif, image/jpeg, image/pjpeg, image/pjpeg");
                            conn.setRequestProperty("Accept-Language","zh-CN");
                            conn.setRequestProperty("Charset","UTF-8");
                            conn.setRequestProperty("Content-Type","application/x-www-form-urlencoded");
                            //conn.setRequestProperty("content-type", "text/html");
                            conn.connect();

                            System.out.println("param:"+params.toString());

                            //转化为JSON发送数据
                            ObjectMapper mapper = new ObjectMapper();
                            String request = mapper.writeValueAsString(params);
                            System.out.println("requestJSON:"+request);

                            //map转化为key=value&的格式
                            /*
                            StringBuffer request = new StringBuffer();//!!!!不能=null
                            Iterator<Map.Entry<String,String>> it = params.entrySet().iterator();
                            String key = null;String value = null;
                            //for(String key : params.keySet()){
                            while (it.hasNext()){
                                Map.Entry<String,String> entry = it.next();
                                key = entry.getKey();value = entry.getValue();
                                System.out.println("key:"+key+"   value:"+value);
                                request.append(key).append("=").append(value).append("&");
                            }
                            request.deleteCharAt(request.length()-1);
                            System.out.println("request: "+request);*/

                            OutputStreamWriter outputStreamWriter = new OutputStreamWriter(conn.getOutputStream(),"utf-8");
                            if(request != null){
                                outputStreamWriter.write(request);
                                outputStreamWriter.flush();
                            }
                            System.out.println("已发送请求");

                            //获取返回JSON内容
                            BufferedReader bufferedReader = null;
                            InputStream is = conn.getInputStream();
                            bufferedReader = new BufferedReader(new InputStreamReader(is,"utf-8"));
                            String str = null;
                            while ((str = bufferedReader.readLine()) != null) {
                                result.append(str);
                            }

                            System.out.println("inputstream:"+is.toString());
                            System.out.println("result:"+result.toString());

                            if(outputStreamWriter != null){
                                outputStreamWriter.close();
                            }

                            if(conn != null){
                                conn.disconnect();
                                conn = null;
                            }
                            return result.toString();
                        }catch (ConnectTimeoutException eTimeOut){
                            System.out.println("eTimeOut,连接超时");
                        }catch (SocketTimeoutException eSocketTimeOut){
                            System.out.println("eSocketTimeOut,响应超时");
                        }catch (FileNotFoundException eFileNotFound){
                            System.out.println("eFileNotFound:  "+eFileNotFound.getMessage());
                        }catch (IOException eIO){
                            eIO.printStackTrace();
                        }catch (Exception e){
                            e.printStackTrace();
                        }
                        return null;
                    }
                }
        );
        new Thread(task).start();
        return task.get();
    }

    public Bitmap PicRequest(final String path){
        FutureTask<Bitmap> task = new FutureTask<Bitmap>(
                new Callable<Bitmap>() {
                    @Override
                    public Bitmap call() {
                        Bitmap bitmap = null;
                        try{
                            URL url = new URL(path);
                            HttpURLConnection con = (HttpURLConnection)url.openConnection();
                            con.setRequestMethod("GET");
                            con.setDoInput(true);
                            con.setDoOutput(true);
                            con.setConnectTimeout(10000);
                            con.setRequestProperty("Accept","image/gif, image/jpeg, image/pjpeg, ");
                            con.setRequestProperty("Accept-Language","zh-CN");
                            con.setRequestProperty("Charset","UTF-8");
                            con.setRequestProperty("Connection","Keep-Alive");

                            InputStream inputStream = con.getInputStream();//
                            bitmap = BitmapFactory.decodeStream(inputStream);
                            inputStream.close();
                        }catch (IOException eIO){
                            eIO.printStackTrace();
                        }catch (Exception e1){
                            e1.printStackTrace();
                        }
                        return bitmap;
                    }
                }
        );
        Thread thread  = new Thread(task);
        thread.start();

        Bitmap result = null;
        try{
            result = task.get();
        }catch(ExecutionException eExecutuin){
            //由于中断线程而无法获取结果的异常
            //return the cause of this throwable or null if the cause is nonexistent or unknown
            eExecutuin.getCause();
        }catch (InterruptedException eInterrupted){
            //线程阻塞
            //中断线程
            thread.interrupt();
        }

        return result;
    }
}
