package com.example.wanjunbi.lsjq_wan.activity;

import android.app.Activity;
import android.os.Bundle;

import com.amap.api.maps.AMap;
import com.amap.api.maps.CameraUpdate;
import com.amap.api.maps.CameraUpdateFactory;
import com.amap.api.maps.MapView;
import com.amap.api.maps.model.LatLng;
import com.amap.api.maps.model.PolygonOptions;
import com.amap.api.maps.model.PolylineOptions;
import com.amap.api.maps.model.TextOptions;
import com.example.wanjunbi.lsjq_wan.R;
import com.example.wanjunbi.lsjq_wan.db.DBHandle;
import com.example.wanjunbi.lsjq_wan.entity.Location;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * Created by wanjunbi on 2017/4/23.
 */

public class MapActivity extends Activity {
    //地图容器
    private MapView mapView;
    //地图控制类
    private AMap aMap;
    private CameraUpdate cameraUpdate;

    private List<Location> jqArea = new ArrayList<Location>();
    //private List<LatLng> Area = new ArrayList<LatLng>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.map);

        mapView = (MapView)findViewById(R.id.map);
        mapView.onCreate(savedInstanceState);

        init();
        long preTime = System.currentTimeMillis();
        for (int i=1;i<6;i++) {
            List<LatLng> Area = new ArrayList<LatLng>();
            jqArea = new DBHandle().GetMaps(i);
            System.out.println("jqArea.size:"+String.valueOf(jqArea.size()));

            for (int j = 0; j < jqArea.size(); j++) {
                LatLng latLng = new LatLng(jqArea.get(j).getLat().doubleValue(), jqArea.get(j).getLng().doubleValue());
                Area.add(j, latLng);
            }
            //配置aMap
            Area.add(Area.get(0));//首尾坐标一致则闭合
            PolylineOptions polylineOptions = new PolylineOptions();
            polylineOptions.addAll(Area);
            polylineOptions.color(0xff3cb371);
            polylineOptions.width(8);
            aMap.addPolyline(polylineOptions);

            //jq名字信息
            TextOptions textOptions = new TextOptions();
            switch (i){
                case 1:
                    textOptions.position(new LatLng(30.58179985,114.2937082));
                    textOptions.text("江汉路及中山大道片区");
                    textOptions.fontColor(0xFF6495ed);
                    textOptions.backgroundColor(0x00000000);
                    textOptions.fontSize(30);
                    break;
                case 2:
                    textOptions.position(new LatLng(30.58183364,114.2974657));
                    textOptions.text("青岛路片区");
                    textOptions.fontColor(0xFF6495ed);
                    textOptions.backgroundColor(0x00000000);
                    textOptions.fontSize(30);
                    break;
                case 3:
                    textOptions.position(new LatLng(30.58622008,114.3001627));
                    textOptions.text("八七会址片区");
                    textOptions.fontColor(0xFF6495ed);
                    textOptions.backgroundColor(0x00000000);
                    textOptions.fontSize(30);
                    break;
                case 4:
                    textOptions.position(new LatLng(30.59231447,114.3033037));
                    textOptions.text("一元路片区");
                    textOptions.fontColor(0xFF6495ed);
                    textOptions.backgroundColor(0x00000000);
                    textOptions.fontSize(30);
                    break;
                case 5:
                    textOptions.position(new LatLng(30.55125861,114.3102605));
                    textOptions.text("昙华林片区");
                    textOptions.fontColor(0xFF6495ed);
                    textOptions.backgroundColor(0x00000000);
                    textOptions.fontSize(30);
                    break;
            }
            aMap.addText(textOptions);
        }
        long aftTime = System.currentTimeMillis();
        System.out.println("TimeCost:"+String.valueOf(aftTime-preTime));

        cameraUpdate = CameraUpdateFactory.newLatLngZoom(new LatLng(30.5761520000,114.3058080000),13);
        aMap.moveCamera(cameraUpdate);

        //TODO 放大后显示街区建筑，并点击进入建筑项页面
    }

    public void init(){
        if (aMap == null){
            aMap = mapView.getMap();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        mapView.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        mapView.onPause();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        mapView.onSaveInstanceState(outState);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mapView.onDestroy();
    }
}
