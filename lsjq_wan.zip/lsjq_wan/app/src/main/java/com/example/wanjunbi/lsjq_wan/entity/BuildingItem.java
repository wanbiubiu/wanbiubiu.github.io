package com.example.wanjunbi.lsjq_wan.entity;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import com.example.wanjunbi.lsjq_wan.db.HttpUtil;
import com.example.wanjunbi.lsjq_wan.db.SQLConfig;

/**
 * Created by wanjunbi on 2017/3/7.
 */

public class BuildingItem {
    public String Name = null;
    public String Info = null;
    public String Location = null;
    public String PicUrl = null;
    //传回图片地址

    public BuildingItem(String name, String info, String location, String picurl){
        this.Name = name;
        this.Info = info;
        this.Location = location;
        this.PicUrl = picurl;
    }

    /**
     * 根据实例PicUrl从网络获取图片
     * @return
     */
    public Bitmap getPic(){
        Bitmap bitmap = null;
        //当数据库图片存在时
        if(this.PicUrl != null) {
            System.out.println("getPic()中picurl:"+this.PicUrl);
            String path = "http://"+SQLConfig.IP + "/"+this.PicUrl;
            bitmap = new HttpUtil().PicRequest(path);
        }else{
            // TODO 设置为加载失败图标
        }
        return bitmap;
    }

}
