package com.example.wanjunbi.lsjq_wan.Stroage;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.content.Context;
import android.graphics.BitmapFactory;
import android.os.Environment;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * Created by wanjunbi on 2017/4/9.
 */

public class BitmapStorage {
    private int buildingID;
    private Context context;
    private Bitmap itemPic;
    DiskLruCache diskLruCache = null;

    public BitmapStorage(int ID){
        this.buildingID = ID;
    }

    //新线程
    public boolean putBitmap(Context context, Bitmap bitmap){
        //创建缓存
        this.itemPic = bitmap;
        this.context = context;
        try{
            File cacheDir = getDiskDir(context,"bitmap");
            if (!cacheDir.exists()){
                cacheDir.mkdir();
            }
            diskLruCache = DiskLruCache.open(cacheDir,getAppVersion(context),1,10 * 1024 * 1024);
            //放入bitmap，buildingID作为key
            DiskLruCache.Editor editor = diskLruCache.edit(String.valueOf(buildingID));
            if (editor != null){
                OutputStream outputStream = editor.newOutputStream(0);
                //bitmap转化为输出流
                itemPic.compress(Bitmap.CompressFormat.JPEG,100,outputStream);
                //System.out.println("bitmap_outputstream:"+outputStream);
                System.out.println("outputstream:"+outputStream.toString());
                editor.commit();
                System.out.println("cache size:"+diskLruCache.size());
                if (outputStream != null){
                    outputStream.close();
                }
            }else {
                editor.abort();
            }
            diskLruCache.flush();
            return true;
        } catch (IOException e){
            e.printStackTrace();
        }
        return false;
    }

    public Bitmap getBitmap(){
        Bitmap bitmap = null;
        try {
            DiskLruCache.Snapshot snapshot = diskLruCache.get(String.valueOf(buildingID));
            if(snapshot != null){
                InputStream is = snapshot.getInputStream(0);
                if (is != null) {
                    bitmap = BitmapFactory.decodeStream(is);
                }
                snapshot.close();
            }else {
                return null;
            }
        }catch (IOException e){
            e.printStackTrace();
        }
        return bitmap;
    }

    public File getDiskDir(Context context, String uniqueName){
        String cachePath;
        if (Environment.MEDIA_MOUNTED.equals(Environment.getExternalStorageState()) || !Environment.isExternalStorageRemovable()){
            cachePath = context.getExternalCacheDir().getPath();
        }else {
            cachePath = context.getCacheDir().getPath();
        }
        String path = cachePath+File.separator+uniqueName;
        System.out.println("bitmap diskDIr:"+path);
        return new File(path);
    }

    public int getAppVersion(Context context){
        try{
            PackageInfo info = context.getPackageManager().getPackageInfo(context.getPackageName(),0);
            return info.versionCode;
        }catch (PackageManager.NameNotFoundException e){
            e.printStackTrace();
        }
        return 1;
    }
}
