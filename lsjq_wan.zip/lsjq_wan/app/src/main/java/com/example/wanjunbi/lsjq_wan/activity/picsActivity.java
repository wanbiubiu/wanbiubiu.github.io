package com.example.wanjunbi.lsjq_wan.activity;


import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.view.View;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import android.support.v4.view.ViewPager;
import android.widget.TextView;
import android.widget.Toast;

import com.example.wanjunbi.lsjq_wan.R;
import com.example.wanjunbi.lsjq_wan.ViewPagerAdapter;
import com.example.wanjunbi.lsjq_wan.db.DBHandle;
import com.example.wanjunbi.lsjq_wan.db.SQLConfig;
import com.example.wanjunbi.lsjq_wan.entity.Pics;


/**
 * Created by wanjunbi on 2017/2/7.
 */

public class picsActivity extends Activity implements ViewPager.OnPageChangeListener{
    private ViewPager viewPager;
    private List<View> viewList = new ArrayList<View>();
    private ViewPagerAdapter pagerAdapter = null;
    private TextView number;
    private TextView name;
    private Map<String,String> picsMap= new HashMap<String,String>();

    private String picName;
    private String picUrl;
    private List<String> urls = new ArrayList<String>();
    private List<String> names = new ArrayList<String>();

    private int jiequID = 0;

    //TODO 缓存已划过的图片


    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pics);
        viewPager = (ViewPager)findViewById(R.id.viewpager);

        Intent intent = this.getIntent();
        jiequID = intent.getIntExtra("jiequID",0);
        //System.out.println("jiequID:"+String.valueOf(jiequID));

        //开启线程获取图片地址信息，得到后设置PagerAdapter及Listener
        MyThread myThread = new MyThread();
        Thread thread = new Thread(myThread);
        thread.start();

       // pagerAdapter = new ViewPagerAdapter(this, imgID);
        //viewPager.setAdapter(pagerAdapter);

        //实现滑动的动态效果
        //viewPager.setOnPageChangeListener(this);
    }


    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

    }

    @Override
    public void onPageSelected(int position) {
        //position 当前页面位置
        if(position == picsMap.size()-1){
            Toast.makeText(picsActivity.this,"最后一张图片",Toast.LENGTH_SHORT).show();
        }else if(position == 0){
            Toast.makeText(picsActivity.this,"第一张图片",Toast.LENGTH_SHORT).show();
        }
        number = (TextView)findViewById(R.id.number);
        number.setText(position+1 +"/"+ picsMap.size());
        name = (TextView)findViewById(R.id.PicName);
        name.setText(names.get(position));
        pagerAdapter.notifyDataSetChanged();
    }

    @Override
    public void onPageScrollStateChanged(int state) {
        //根据state开启多线程加载图片
        /*if (state == 2){
            MyThread myThread = new MyThread();
            Thread thread = new Thread(myThread);
            thread.start();
        }*/
    }


    class MyThread implements Runnable{
        @Override
        public void run() {
            Looper.prepare();
            boolean urlDownload = picUrlDownload();
            if(urlDownload){
                Message msg = new Message();
                msg.what = 10;
                mHandlerUI.sendMessage(msg);
            }else {
                Message msg = new Message();
                msg.what = -1;
                mHandlerUI.sendMessage(msg);
            }
        }
    }

    @SuppressLint("NewApi")
    private boolean picUrlDownload(){
        try{
            picsMap = new DBHandle().GetJQPics(jiequID);
        }catch (Exception e){
            e.printStackTrace();
        }

        if(picsMap.isEmpty()){
            return false;
        }else{
            //在这里处理picslist
            System.out.println("thread内的picslist: "+picsMap.toString());
            Iterator<Map.Entry<String,String>> entries = picsMap.entrySet().iterator();
            while (entries.hasNext()){
                Map.Entry<String,String> entry = entries.next();
                if(entry.getValue() != null) {
                    picName = entry.getKey();
                    picUrl = "Http://" + SQLConfig.IP + "/" + entry.getValue();
                }
                urls.add(picUrl);
                names.add(picName);
            }
        }
        //System.out.println("urls:"+urls.toString());
        //System.out.println("names:"+names.toString());
        pagerAdapter = new ViewPagerAdapter(this, urls);
        viewPager.setOnPageChangeListener(this);
        return true;
    }

    private Handler mHandlerUI = new Handler(){
        public void handleMessage(Message msg){
            switch (msg.what){
                case 10:
                    //下载完picsUrlList，设置PagerAdapter
                    viewPager.setAdapter(pagerAdapter);
                    break;
                default:
                    //下载失败
                    break;
            }
        }
    };
}

/*
import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.view.GestureDetector;
import android.view.GestureDetector.OnGestureListener;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewFlipper;

public class picsActivity extends Activity implements GestureDetector.OnGestureListener{
    ViewFlipper flipper;
    GestureDetector detector;
    Animation[] animations = new Animation[4];
    final int FLIP_DISTANCE = 50;

    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pics);

        TextView textView = (TextView)findViewById(R.id.PicsTitle);
        Intent intentp = getIntent();
        int jiequID = intentp.getIntExtra("jiequID",0);
        //根据intentp内jiequID显示标题

        switch (jiequID) {
            case 0:
                textView.setText("江汉路及中山大道片区");
                break;
            case 1:
                textView.setText("青岛路片区");
                break;
            case 2:
                textView.setText("八七会址片区");
                break;
            case 3:
                textView.setText("一元路片区");
                break;
            case 4:
                textView.setText("昙华林片区");
                break;
        }

        detector = new GestureDetector(this,this);
        flipper = (ViewFlipper)this.findViewById(R.id.flipper);

        flipper.addView(addImageView(R.drawable.bgfz001));
        flipper.addView(addImageView(R.drawable.bgfz002));
        flipper.addView(addImageView(R.drawable.bgfz003));
        flipper.addView(addImageView(R.drawable.bgfz004));
        flipper.addView(addImageView(R.drawable.bgfz005));

        animations[0] = AnimationUtils.loadAnimation(this,R.anim.left_in);
        animations[1] = AnimationUtils.loadAnimation(this,R.anim.left_out);
        animations[2] = AnimationUtils.loadAnimation(this,R.anim.right_in);
        animations[3] = AnimationUtils.loadAnimation(this,R.anim.right_out);
    }

    //import android.view.View;
    private View addImageView(int resID){
        ImageView imageView = new ImageView(this);
        imageView.setImageResource(resID);
        imageView.setScaleType(ImageView.ScaleType.CENTER);
        return imageView;
    }

    @Override
    public boolean onFling(MotionEvent event1, MotionEvent event2, float velocityX, float velocityY){
        if (event1.getX()-event2.getX() > FLIP_DISTANCE){
            flipper.setInAnimation(animations[0]);
            flipper.setOutAnimation(animations[1]);
            if (flipper.getCurrentView() != addImageView(R.drawable.bgfz005)) {
                flipper.showPrevious();
            }else{
                Toast.makeText(this,"当前为最后一张图片",Toast.LENGTH_LONG).show();
            }
            return true;
        }
        else if (event2.getX()-event1.getX() > FLIP_DISTANCE){
            flipper.setInAnimation(animations[2]);
            flipper.setOutAnimation(animations[3]);
            if (flipper.getCurrentView() != addImageView(R.drawable.bgfz001)) {
                flipper.showNext();
            }else {
                Toast.makeText(this,"当前为第一张图片",Toast.LENGTH_LONG).show();
            }
            return true;
        }
        return false;
    }

    @Override
    public boolean onTouchEvent(MotionEvent event){
        return detector.onTouchEvent(event);
    }

    @Override
    public boolean onDown(MotionEvent event){
        return false;
    }

    @Override
    public void onLongPress(MotionEvent event){
    }

    @Override
    public boolean onScroll(MotionEvent event1, MotionEvent event2, float arg2, float arg3){
        return false;
    }

    @Override
    public  void onShowPress(MotionEvent event){
    }

    @Override
    public boolean onSingleTapUp(MotionEvent event){
        return false;
    }
}
*/
