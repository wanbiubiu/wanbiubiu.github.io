package com.example.wanjunbi.lsjq_wan.db;

import com.amap.api.maps.model.LatLng;
import com.example.wanjunbi.lsjq_wan.entity.BuildingItem;
import com.example.wanjunbi.lsjq_wan.entity.Location;
import com.example.wanjunbi.lsjq_wan.entity.Pics;

import org.codehaus.jackson.map.ObjectMapper;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 访问数据库模块
 * 不同功能的访问方法
 */

public class DBHandle{
    public String IP;
    public DBHandle(){
        this.IP = SQLConfig.IP;
    }

    /**
     * 获取jqActivity页面的街区简介文本信息
     * @param jiequID 街区编号
     * @return 文本信息
     */
    public String GetJqIntroduction(int jiequID){
        String url = "http://"+IP+"/LSJQServer/servlet/JQIntroServlet";
        String info = null;//返回信息
        String intro = null;
        //Map<String,String> requestMap = new HashMap<String, String>();
        //requestMap.put("jq",String.valueOf(jiequID+1));//数据库第一项为1
        try{
            info = new HttpUtil().GetRequest(url,"jq",String.valueOf(jiequID));
        //    System.out.println("requestmap:"+requestMap.toString());
            ObjectMapper mapper = new ObjectMapper();
            Map<String,String> responseMap = mapper.readValue(info, Map.class);
            System.out.println("info:"+info);
            System.out.println("responsemap:"+responseMap.toString());
            String statuCode = (String)responseMap.get("statuCode");
            if(statuCode.equals("200")){
                intro = responseMap.get("introduction");
            }else {
                intro = "未查询到相关信息";
            }
        }catch (IOException eIO){
            eIO.printStackTrace();
        }catch (Exception e){
            e.printStackTrace();
        }
        return intro;
    }

    /**
     * 获取街区建筑列表
     * @param jiequID 街区编号
     * @return 街区建筑列表
     */
    public List<String> GetBuildingList(int jiequID){
        String url = "http://"+IP+"/LSJQServer/servlet/JQBuildingListServlet";
        List<String> buildingList = new ArrayList<String>();
        Map<String,String> map = new HashMap<String, String>();
        map.put("jq",String.valueOf(jiequID));
        try{
            //Post方法不能获取数据
            String result = new HttpUtil().PostRequest(url,map);//GetRequest(url,"jq", String.valueOf(jiequID+1));
            ObjectMapper mapper = new ObjectMapper();
            Map<String,List<String>> responseMap = mapper.readValue(result, Map.class);
            List<String> statuCode = (List<String>)responseMap.get("statuCode");
            if(statuCode.get(0).equals("200")){
                //预防格式不统一
                List<String> list = responseMap.get("list");
                String json = mapper.writeValueAsString(list);
                buildingList = mapper.readValue(json,List.class);
            }
        System.out.println("buildinglist:"+buildingList.toString());
        }catch (IOException eIO){
            eIO.printStackTrace();
        } catch (Exception e){
            e.printStackTrace();
        }
        return buildingList;
    }

    /**
     * 获取建筑列表单个建筑信息
     * @param buildingID 建筑编号，与数据库中编号相同
     * @return BuildingItem对象
     */
    public BuildingItem GetBuildingItem(int buildingID){
        BuildingItem buildingItem = null;
        String url = "http://"+IP+"/LSJQServer/servlet/JQBuildingItemServlet";
        Map<String,String> map = new HashMap<String, String>();
        map.put("ID",String.valueOf(buildingID));
        try{
            String result = new HttpUtil().GetRequest(url,"ID",String.valueOf(buildingID));
            ObjectMapper mapper = new ObjectMapper();
            Map<String,String> bmap = mapper.readValue(result,Map.class);
            if (bmap.get("statuCode").equals("200")){
                String name = bmap.get("itemName");
                String info = bmap.get("itemIntro");
                String location = bmap.get("itemLocation");
                String picurl = bmap.get("itemPicUrl");
                buildingItem = new BuildingItem(name,info,location,picurl);

                System.out.println("buildingitem:"+buildingItem.toString());
            }
        }catch (IOException eIO){
            eIO.printStackTrace();
        }catch (Exception e){
            e.printStackTrace();
        }
        return buildingItem;
    }

    /**
     * 返回map<String, Object>,包括String statuCode、List<JQPics> picsUrlList
     * @param jiequID
     * @return
     */
    public Map<String,String> GetJQPics(int jiequID){
        Map<String,String> picsMap= new HashMap<String, String>();
        String url = "http://"+IP+"/LSJQServer/servlet/JQPicsServlet";
        //Map<String,String> map = new HashMap<String, String>();
        //map.put("jq",String.valueOf(jiequID));

        try{
            String result = new HttpUtil().GetRequest(url,"jq",String.valueOf(jiequID));
            ObjectMapper mapper = new ObjectMapper();
            Map<String,Object> resultmap = mapper.readValue(result,Map.class);
            if(resultmap.get("statuCode").equals("200")){
                picsMap = (Map<String,String>) resultmap.get("picsUrl");
            }

        }catch (IOException eIO){
            eIO.printStackTrace();
        }catch (Exception e){
            e.printStackTrace();
        }
        return picsMap;
    }

    public List<String> GetItemPics(int buildingID){

        List<String> itemUrls = new ArrayList<String>();
        String url = "http://"+IP+"/LSJQServer/servlet/ItemPicsServlet";

        try{
            String result = new HttpUtil().GetRequest(url,"buildingID",String.valueOf(buildingID));
            ObjectMapper mapper = new ObjectMapper();
            Map<String,Object> resultMap = mapper.readValue(result,Map.class);
            System.out.println("ItemPicsUrl:"+resultMap.toString());
            if(resultMap.get("statuCode").equals("200")){
                itemUrls = (List<String>) resultMap.get("picsUrl");
            }
        }catch (IOException eIO){
            eIO.printStackTrace();
        }catch (Exception e){
            e.printStackTrace();
        }
        return itemUrls;
    }

    public List<Location> GetMaps(int jiequID){
        List<Location> jqArea = new ArrayList<Location>();
        String url = "http://"+IP+"/LSJQServer/servlet/MapsServlet";

        try{
            String result = new HttpUtil().GetRequest(url,"jiequID",String.valueOf(jiequID));
            ObjectMapper mapper = new ObjectMapper();
            Map<String,Object> resultMap = mapper.readValue(result,Map.class);
            if(resultMap.get("statuCode").equals("200")){
                List<Location> list = (List<Location>) resultMap.get(String.valueOf(jiequID));
                String json = mapper.writeValueAsString(list);
                Location[] arr = mapper.readValue(json, Location[].class);
                jqArea = Arrays.asList(arr);
            }
        }catch (IOException eIO){
            eIO.printStackTrace();
        }catch (Exception e){
            e.printStackTrace();
        }
        return jqArea;
    }

    public List<Location> GetJQMap(int jiequID){
        List<Location> jqSpots = new ArrayList<Location>();
        String url = "http://"+IP+"/LSJQServer/servlet/JQMapServlet";

        try{
            String result = new HttpUtil().GetRequest(url,"jiequID",String.valueOf(jiequID));
            System.out.println("jqmap:"+result);
            ObjectMapper mapper = new ObjectMapper();
            Map<String,Object> resultMap = mapper.readValue(result,Map.class);
            if(resultMap.get("statuCode").equals("200")){
                List<Location> list = (List<Location>) resultMap.get(String.valueOf(jiequID));
                String json = mapper.writeValueAsString(list);
                Location[] arr = mapper.readValue(json,Location[].class);
                jqSpots = Arrays.asList(arr);
                //System.out.println("jqSpots2:"+jqSpots.get(2).getName());
            }
        }catch (IOException eIO){
            eIO.printStackTrace();
        }catch (Exception e){
            e.printStackTrace();
        }
        return jqSpots;
    }
}
