package com.example.wanjunbi.lsjq_wan.activity;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.wanjunbi.lsjq_wan.R;
import com.example.wanjunbi.lsjq_wan.Stroage.BitmapStorage;
import com.example.wanjunbi.lsjq_wan.db.DBHandle;
import com.example.wanjunbi.lsjq_wan.entity.BuildingItem;

import java.io.Serializable;

/**
 * Created by wanjunbi on 2017/2/9.
 */

//继承SrocllView
public class buildingitemActivity extends Activity implements Serializable{
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.buildingitem);

        final Intent intent = getIntent();
        final Bundle bundle = intent.getExtras();
        final int jiequID = bundle.getInt("jiequID");
        final int buildingID = bundle.getInt("buildingID");
        final int ID = 1000+(jiequID)*100+buildingID;//数据库中对应的建筑ID

        TextView itemtitle = (TextView)findViewById(R.id.buildingitemTitle);
        TextView iteminfo = (TextView)findViewById(R.id.ItemInfo);
        TextView itemlocation = (TextView)findViewById(R.id.ItemLocation);
        final ImageView itemimg = (ImageView)findViewById(R.id.ItemImg);

        //获取服务器传回buildingItem信息
        BuildingItem buildingItem = new DBHandle().GetBuildingItem(ID);
        System.out.println("picurl:"+buildingItem.PicUrl);

        //动态修改
        //TODO: 先显示页面，然后加载图片并刷新
        itemtitle.setText(buildingItem.Name);
        iteminfo.setText(buildingItem.Info);
        itemlocation.setText(buildingItem.Location);
        itemimg.setImageResource(R.drawable.picture_loading800);

        final Bitmap itemPic = buildingItem.getPic();
        if(itemPic != null) {
            itemimg.setImageBitmap(itemPic);
            final BitmapStorage store = new BitmapStorage(ID);
            if (store.putBitmap(this,itemPic)){
                System.out.println("bitmap存放成功");
            }else {
                System.out.println("bitmap存放失败");
            }

            itemimg.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intentPic = new Intent(buildingitemActivity.this,ViewItemPicActivity.class);
                    Bundle bundle = new Bundle();
                    bundle.putInt("ID",ID);
                    intentPic.putExtras(bundle);
                    System.out.println("ID:"+ID);
                    //intent.putExtra("diskLruCache",store);
                    //intent传递store，使读取使用同一对象
                    startActivity(intentPic);
                }
            });
        }else{
            itemimg.setImageResource(R.drawable.picfailed);
            //itemimg.refreshDrawableState();
        }
    }


}
