package com.example.wanjunbi.lsjq_wan.db;

/**
 * Created by wanjunbi on 2017/3/3.
 */

public class SQLConfig {
    //public static final String IP = "192.168.0.120:8080";
    public static final String IP = "202.114.41.163:8088";
}