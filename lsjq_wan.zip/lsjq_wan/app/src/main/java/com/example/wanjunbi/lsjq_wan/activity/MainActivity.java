package com.example.wanjunbi.lsjq_wan.activity;

import android.content.Intent;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.wanjunbi.lsjq_wan.R;

public class MainActivity extends Activity implements View.OnClickListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button map = (Button) findViewById(R.id.lsjq_map);
        Button jhl = (Button) findViewById(R.id.jhl);
        Button qdl = (Button) findViewById(R.id.qdl);
        Button bqhz = (Button) findViewById(R.id.bqhz);
        Button yyl = (Button) findViewById(R.id.yyl);
        Button thl = (Button) findViewById(R.id.thl);

        jhl.setOnClickListener(this);
        qdl.setOnClickListener(this);
        bqhz.setOnClickListener(this);
        yyl.setOnClickListener(this);
        thl.setOnClickListener(this);

        map.setOnClickListener(this);

        // 把按钮 Button[]及街区编号抽象出来放到数组里，遍历数组，方便以后添加新的按钮
    /*    Button[] btns = new Button[5];
        for (int i = 0; i < btns.length; i++) {
            int btnsID = getResources().getIdentifier(getResources().getStringArray(R.array.jiequ)[i],"string",getPackageName());
            btns[i] = (Button)findViewById(btnsID);
            btns[i].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(MainActivity.this,jqActivity.class);
                //    intent.putExtra("jiequID",i);
                    startActivity(intent);
                }
            });
        }*/

        //intent传递街区ID
    }

    public void onClick(View view){
        //Intent intent = new Intent(MainActivity.this, jqActivity.class);
        switch (view.getId()) {
            case R.id.jhl:
                Intent intent1 = new Intent(MainActivity.this, jqActivity.class);
                intent1.putExtra("jiequID", 1);
                startActivity(intent1);
                break;
            case R.id.qdl:
                Intent intent2 = new Intent(MainActivity.this, jqActivity.class);
                intent2.putExtra("jiequID", 2);
                startActivity(intent2);
                break;
            case R.id.bqhz:
                Intent intent3 = new Intent(MainActivity.this, jqActivity.class);
                intent3.putExtra("jiequID", 3);
                startActivity(intent3);
                break;
            case R.id.yyl:
                Intent intent4 = new Intent(MainActivity.this, jqActivity.class);
                intent4.putExtra("jiequID", 4);
                startActivity(intent4);
                break;
            case R.id.thl:
                Intent intent5 = new Intent(MainActivity.this, jqActivity.class);
                intent5.putExtra("jiequID", 5);
                startActivity(intent5);
                break;
            case R.id.lsjq_map:
                Intent intentMap = new Intent(MainActivity.this,MapActivity.class);
                startActivity(intentMap);
                break;
    }
}
}
