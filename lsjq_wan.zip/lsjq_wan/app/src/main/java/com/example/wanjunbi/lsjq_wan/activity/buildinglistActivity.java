package com.example.wanjunbi.lsjq_wan.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.example.wanjunbi.lsjq_wan.R;
import com.example.wanjunbi.lsjq_wan.db.DBHandle;

import java.util.List;


/**
 * Created by wanjunbi on 2017/1/25.
 */

public class buildinglistActivity extends Activity {

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.buildinglist);

        Intent intentb = getIntent();
        final int jiequID = intentb.getIntExtra("jiequID",0);

        //使用BaseAdapter
        ListView list = (ListView) findViewById(R.id.listview);
        final List<String> buildingList = new DBHandle().GetBuildingList(jiequID);

        System.out.println("buildingList:"+buildingList.size());

        BaseAdapter adapter = new BaseAdapter() {
            @Override
            public int getCount() {
                return buildingList.size();
            }

            @Override
            public Object getItem(int i) {
                return null;
            }

            @Override
            public long getItemId(int i) {
                return i;
            }

            @Override
            public View getView(final int i, View view, ViewGroup viewGroup) {
                final LinearLayout linear = new LinearLayout(buildinglistActivity.this);
                linear.setOrientation(LinearLayout.HORIZONTAL);
                final TextView text = new TextView(buildinglistActivity.this);
                ImageView image = new ImageView(buildinglistActivity.this);

                image.setImageResource(R.mipmap.ic_launcher);
                text.setText(buildingList.get(i));
                text.setTextSize(20);
                text.setPadding(0,10,0,10);
                linear.addView(image);
                linear.addView(text);
                
                return linear;
            }
        };
        list.setAdapter(adapter);

        //点击列表项跳转显示建筑信息及图片
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int buildingID, long l) {
                Intent intent = new Intent(buildinglistActivity.this,buildingitemActivity.class);
                Bundle bundle = new Bundle();

                //buildingID从0开始
                bundle.putInt("buildingID", buildingID+1);
                bundle.putInt("jiequID",jiequID);
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });
    }
}