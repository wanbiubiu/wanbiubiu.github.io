package com.example.wanjunbi.lsjq_wan.entity;

import com.amap.api.maps.model.LatLng;

import java.math.BigDecimal;

/**
 * Created by wanjunbi on 2017/4/24.
 */

public class Location {
    private String name;
    private BigDecimal lng;
    private BigDecimal lat;

    public Location(){
        super();
    }

    public Location(String name,BigDecimal lng,BigDecimal lat){
        this.name = name;
        this.lng = lng;
        this.lat = lat;
    }

    public String getName(){
        return name;
    }
    public BigDecimal getLng(){
        return lng;
    }public BigDecimal getLat(){
        return lat;
    }

    public void setID(String name){
        this.name = name;
    }
    public void setLng(BigDecimal lng){
        this.lng = lng;
    }
    public void setLat(BigDecimal lat){
        this.lat = lat;
    }
}
