package com.example.wanjunbi.lsjq_wan.entity;

/**
 * Created by wanjunbi on 2017/4/16.
 */

public class Pics {
    private String name = null;
    private String picUrl = null;

    //TODO 服务器传回buildingitemid，作为DiskLruCache缓存的key，方便查找

    public Pics(String name, String picUrl){
        this.name = name;
        this.picUrl = picUrl;
    }

    public String getName(){
        return this.name;
    }

    public String getPicUrl(){
        return this.picUrl;
    }
}
