package com.example.wanjunbi.lsjq_wan;

import android.content.Context;
import android.graphics.Bitmap;
import android.support.v4.view.PagerAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.example.wanjunbi.lsjq_wan.db.HttpUtil;
import com.example.wanjunbi.lsjq_wan.db.SQLConfig;
import com.example.wanjunbi.lsjq_wan.entity.Pics;

import java.util.List;

/**
 * Created by wanjunbi on 2017/2/15.
 */

public class ViewPagerAdapter extends PagerAdapter{

    private List<View> list;
    //private int[] imgID;
    private Context context;
    private List<String> picsUrl;
    private Bitmap bitmap;

    public ViewPagerAdapter(Context context , List<String> urls){
        this.context = context;
        this.picsUrl = urls;

    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View picItemView = inflater.inflate(R.layout.picsview,null);
        ImageView imageView = (ImageView)picItemView.findViewById(R.id.picsItem);
        //下载图标
        imageView.setImageResource(R.drawable.picture_loading800);

        String url = picsUrl.get(position);
        //下载该位置照片
        if(url != null){
            try{
                bitmap = new HttpUtil().PicRequest(url);
            }catch (OutOfMemoryError eOOM){
                eOOM.printStackTrace();
            }
            if(bitmap != null){
                imageView.setImageBitmap(bitmap);
                //TODO show PicName
            }else {
                imageView.setImageResource(R.drawable.picfailed);
            }
        }else{
            imageView.setImageResource(R.drawable.picfailed);
        }
        container.addView(picItemView);
        return picItemView;
    }

    @Override
    public int getCount() {
        return picsUrl.size();
    }

    @Override
    public boolean isViewFromObject(View arg0, Object arg1) {
        return arg0 == arg1;
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        View view = (View) object;
        container.removeView(view);
    }
}
